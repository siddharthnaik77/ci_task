
#CODEIGNITER MySQL-CRUD

<b>Resource:</b> </br>
1. Codeigniter 3
2. MySQL
3. Bootstrap 

<b>Feature:</b> 
1. Create 
2. Update 
3. View 
4. Delete
5. Search Option
6. Pagination

<a  href="http://dev.techcanva.org/ci-mysql-crud-demo/" target="_blank" >Demo</a>

