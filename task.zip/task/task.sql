-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2019 at 08:29 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `semesters` int(10) NOT NULL,
  `duration` int(11) NOT NULL,
  `desc` longtext NOT NULL,
  `allocated_school` varchar(100) DEFAULT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '1',
  `is_delete` enum('0','1') NOT NULL DEFAULT '0',
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `semesters`, `duration`, `desc`, `allocated_school`, `is_active`, `is_delete`, `created_date`) VALUES
(1, 'MCA', 3, 5, 'sddddddddddddddddddddddddddddddd', NULL, '1', '0', '2019-11-29 20:50:19'),
(2, 'BCA', 5, 2, 'dsdvs', NULL, '1', '0', '2019-11-30 04:23:54'),
(3, 'MCA', 3, 3, 'sddddddddddddddddddddddddddddddd', NULL, '1', '0', '2019-11-30 05:50:13'),
(4, 'ff', 4, 3, 'sss', '1,2', '1', '1', '2019-11-30 05:59:34'),
(5, 'MCAsds', 1, 1, 'sddddddddddddddddddddddddddddddd', '14,0', '1', '0', '2019-11-30 06:03:44'),
(6, 'x', 3, 2, 'sfdf', NULL, '1', '0', '2019-11-30 07:06:39'),
(7, 'MCA', 3, 5, 'hvjhgvhv', NULL, '1', '0', '2019-11-30 07:07:39'),
(8, 'BBA', 3, 2, 'sddddddddddddddddddddddddddddddd', NULL, '1', '0', '2019-11-30 07:13:37'),
(9, 'Bcom', 3, 4, 'lorium ', '0', '1', '0', '2019-11-30 07:14:07'),
(10, 'Mcom', 4, 3, 'test', '0,0', '1', '0', '2019-11-30 07:14:26'),
(11, 'MBA', 3, 3, 'test', NULL, '1', '0', '2019-11-30 07:14:45'),
(12, 'IIT', 3, 3, 'trret', NULL, '1', '0', '2019-11-30 07:19:20'),
(13, 'TEST', 1, 1, 'test', NULL, '1', '0', '2019-11-30 07:23:05');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `school_email` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `country` varchar(50) NOT NULL,
  `allocated_course` varchar(100) DEFAULT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '1',
  `is_delete` enum('0','1') NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`school_id`, `school_name`, `school_email`, `address`, `country`, `allocated_course`, `is_active`, `is_delete`, `created_at`) VALUES
(1, 'Rubel', 'r@a.com', '01712727574', 'Bangladesh', NULL, '1', '1', '2017-08-23 10:15:23'),
(2, 'Bhg', 'b@adf.com', '123', '', NULL, '1', '0', '2017-08-23 10:15:23'),
(13, 'ddd', 'admin@bicri.com', 'asdf', 'india', NULL, '1', '0', '2017-08-24 09:25:07'),
(12, 'Abc', 'admin@bicri.com', '34534532', '43534', NULL, '1', '0', '2017-08-24 09:07:00'),
(6, 'asdf', 'bicri@admi.com', '345234', 'asdf', NULL, '1', '0', '2017-08-23 11:19:39'),
(7, 'dsfg', 'bicri@admi.com', 'Female', '3245', NULL, '1', '1', '2017-08-23 11:21:53'),
(8, 'Abc', 'bicri@admi.com', 'Male', '345', NULL, '1', '1', '2017-08-23 11:27:11'),
(9, 'dsfg', 'bicri@admi.com', 'Female', 'asdf', NULL, '1', '0', '2017-08-23 11:27:53'),
(10, 'ccde', 'admin@bicri.com', '53245', 'asdf', NULL, '1', '0', '2017-08-23 11:30:37'),
(11, 'Abc', 'admin@bicri.com', '34534532', '2345', NULL, '1', '1', '2017-08-24 08:10:34'),
(14, 'siddharth', 'admin@bicri.com', '34534532', 'asdf', '2,3,4', '1', '0', '2017-08-24 09:44:21'),
(0, 'Abcddd', 'dsd@sd.sd', 'zxcc', 'india', '1,2', '1', '0', '2019-11-30 10:35:31'),
(0, 'siddharth', 'dsd@sd.sd', 'zxcc', 'india', '1,2', '1', '0', '2019-11-30 10:35:49'),
(0, 'sneha', 'dsd@sd.sd', 'zxcc', 'india', '1,2', '1', '0', '2019-11-30 10:36:08'),
(0, 'ddd', 'dsd@sd.sd', 'zxcc', 'india', '1,2', '1', '0', '2019-11-30 10:36:24'),
(0, 'RK', 'rk@gmail.com', 'zxcc', 'india', '1,3,5', '1', '0', '2019-11-30 12:38:24'),
(0, 'VK', 'vk@gmail.com', 'mapusa', 'goa', '1,2', '1', '0', '2019-11-30 12:52:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
