<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Course_model extends CI_Model{

	public function getCoursesCount(){
		$this->db->select('*');
		$this->db->from('courses');
		$this->db->where('is_delete','0');
		$query = $this->db->get();
		return $query->num_rows();
	}

	public function getCourses($limit, $start,$searchData){
		$this->db->select('*');
		$this->db->from('courses');
		$this->db->where('is_delete','0');
		if ($searchData != '') {
			$this->db->like('course_name', $searchData);
        }
		$this->db->limit($limit, $start);
		$query = $this->db->get();
		return $query->result_array();	
	}

	public function getCourse($id){
		$this->db->select('*');
		$this->db->from('courses');
		$this->db->where('course_id',$id);
		$this->db->where('is_delete','0');
		$query = $this->db->get();
		return $query->row_array();	
	}

	public function updateCourse($data,$id){
		$this->db->where('course_id',$id);
		$this->db->update('courses',$data);
		return true;
	}

	public function deleteCourse($id){
		$this->db->set('is_delete','1');
		$this->db->where('course_id',$id);
		$this->db->update('courses');
		return true;
	}

	public function addCourse($data){
		$this->db->insert('courses', $data);
		return true;	
	}
}


?>