<div class="container " > 
    

    <div class="row content">

     
           
        <a type="button" href="<?php echo site_url(); ?>"  class="button button-purple mt-12 pull-right">View School List</a> 
     
 <h3>ADD School Info</h3>
                  <?php 
        
        if(isset($_SESSION['message'])){
               echo "<p class='custom-alert'>".$_SESSION['message']."</p>";
         unset($_SESSION['message']);
        }
    
        
        ?>
     
          <hr/>
           
           
           
           
   <form method="post"  id="create_school_info_frm" action="<?php echo site_url('School/create_school_info'); ?>" >
            <div class="form-group">
                <label for="student_name">Name:</label>
                <input type="text" name="school_name" id="school_name" class="form-control" required maxlength="50">
            </div>
            <div class="form-group">
                <label for="email_address">Email address:</label>
                <input type="email" class="form-control" name="email_address" id="email_address" required maxlength="50">
            </div>
            <div class="form-group">
                <label for="contact">Address:</label>
                <input type="text" class="form-control" name="contact" id="contact"  maxlength="50">
            </div>
            
            <div class="form-group">
                <label for="country">Country:</label>
                <input type="text" name="country" name="country" id="country" class="form-control"  maxlength="50">
            </div>
            <?php if(!empty($courses_list)) { ?>
            <div class="form-group">
                <label for="gender">Courses:</label>
                <select id="chkveg" multiple="multiple" name="courses[]">
                  <?php
                  foreach ($courses_list as $key => $value) { ?>
                    <option value="<?php echo $value['course_id']; ?>">
                      <?php echo $value['course_name']; ?></option> 
                  <?php }
                  ?>
                    
                </select>
            </div>
            <?php } ?> 
                <div class="form-group mb-50">
            <input type="submit" class="button button-green  pull-right"  value="Submit"/>
                </div>
                
        </form> 
  
     
   
  </div>
     
</div>
