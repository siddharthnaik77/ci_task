
 <div class="row ">
        <div class="col-lg-2">
          <h3>Coueses List</h3>   
        </div>
        <div class="col-lg-8 mt-12" >
            <form action="" method="get">
        
                            <div class="input-group col-md-12">
                                <input type="text" value="<?php if(isset($_GET['search_input'])){echo $_GET['search_data'];} ?>"  id="search_data" name="search_data"  class="form-control" placeholder="Search" />
                                <span class="input-group-btn">
                                    <button class="button button-green" type="submit">
                                        <span class=" glyphicon glyphicon-search"></span>
                                    </button>
                                </span>
                            </div>
            
            
        </form>
                    
       </div>
          <div class="col-lg-2 ">
              <a href="<?php echo  base_url('add_course');?>"  class="button button-purple mt-12 pull-right" > Create Coueses</a> 
      
          </div>
    </div>
         <?php 
        
        if($this->session->flashdata('message')){
                echo "<p class='custom-alert'>".$this->session->flashdata('message');"</p>";
        // unset($_SESSION['message']);
       }
     
        ?>
<table class="table">
            <thead>
                <tr>
             
                    <th>Course Name</th>
                    <th>Semester</th>
                    <th>Duration</th>
                    <th>Description</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                
          
                <?php

                if(isset($courses_list)){
                    foreach ($courses_list as $key => $value) {
                        
                ?>

                <tr >
                   
                    <td><?php echo  $value['course_name'];?></td>
                    <td><?php echo  $value['semesters'];?></td>
                    <td><?php echo  $value['duration'];?></td>
                    <td><?php echo  $value['desc'];?></td>
                    
                 
                <td class="text-right">
                 
                    <a href="<?php echo site_url('delete-course-info').'/'.$value['course_id'];?>"    class="button button-red" >Delete</a> 
                  
                    <a href="<?php echo site_url('update-course-info').'/'.$value['course_id'];?>"   class="button button-blue" >Edit</a> 
                  
                    <a  href="<?php echo site_url('view-course-info').'/'.$value['course_id'];?>"   class="button button-green" >View</a> 

                    
                
                </td>
                    
                    
                    
                </tr>
                
                <?php
                
                    }
                }
                ?>
                

           </tbody>
        </table>
    

<div class="pull-right">
 
   <?php if(isset($pagination)) {
       echo $pagination;
                
        }
        ?>
   
</div>

