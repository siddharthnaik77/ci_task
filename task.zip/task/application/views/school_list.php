
 <div class="row ">
        <div class="col-lg-2">
          <h3>School List</h3>   
        </div>
        <div class="col-lg-8 mt-12" >
            <form action="" method="get">
        
                            <div class="input-group col-md-12">
                                <input type="text" value="<?php if(isset($_GET['search_input'])){echo $_GET['search_data'];} ?>"  id="search_data" name="search_data"  class="form-control" placeholder="Search" />
                                <span class="input-group-btn">
                                    <button class="button button-green" type="submit">
                                        <span class=" glyphicon glyphicon-search"></span>
                                    </button>
                                </span>
                            </div>
            
            
        </form>
                    
       </div>
          <div class="col-lg-2 ">
              <a  href="<?php echo base_url('add_school');?>" class="button button-purple mt-12 pull-right" > Create School</a> 
      
          </div>
    </div>
         <?php 
        
        if($this->session->flashdata('message')){
                echo "<p class='custom-alert'>".$this->session->flashdata('message');"</p>";
        // unset($_SESSION['message']);
       }
     
        ?>
<table class="table">
            <thead>
                <tr>
             
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact</th>
                    <th>Country</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                
          
                <?php

                if(isset($student_list) && !empty($student_list)){
                    foreach ($student_list as $key => $value) {
                        
                ?>

                <tr >
                   
                    <td><?php echo  $value['school_name'];?></td>
                    <td><?php echo  $value['school_email'];?></td>
                    <td><?php echo  $value['address'];?></td>
                    <td><?php echo  $value['country'];?></td>
                    
                 
                <td class="text-right">
                 
                    <a href="<?php echo site_url('delete-school-info').'/'.$value['school_id'];?>"    class="button button-red" >Delete</a> 
                  
                    <a href="<?php echo site_url('update-school-info').'/'.$value['school_id'];?>"   class="button button-blue" >Edit</a> 
                  
                    <a  href="<?php echo site_url('view-school-info').'/'.$value['school_id'];?>"   class="button button-green" >View</a> 

                    
                
                </td>
                    
                    
                    
                </tr>
                
                <?php
                
                    }
                }else{ ?>
                    <p>No Data Found</p>
                <?php }
                ?>
                

           </tbody>
        </table>
    

<div class="pull-right">
 
   <?php if(isset($pagination)) {
       echo $pagination;
                
        }
        ?>
   
</div>

 

