<div class="container " > 
    

    <div class="row content">

     
           
        <a type="button" href="<?php echo site_url('courses'); ?>"  class="button button-purple mt-12 pull-right">View Course List</a> 
     
 <h3>Update Course Info||<?php echo $course_info['course_name']; ?></h3>
                  <?php 
        
        if(isset($_SESSION['message'])){
               echo "<p class='custom-alert'>".$_SESSION['message']."</p>";
         unset($_SESSION['message']);
        }
    
        
        ?>
     
          <hr/>
           
           
           
           
    <form method="post" action="">
        <input type="hidden" name="course_id" value="<?php  if(isset($course_info['course_id'])){echo $course_info['course_id']; }?>" id=""  >
 
   <div class="form-group">
       
    <label for="school_name">Course Name:</label>
    
    <input type="text" name="course_name" value="<?php  if(isset($course_info['course_name'])){echo $course_info['course_name']; }?>" id="course_name" class="form-control" required="" maxlength="50">
 
   </div>
  <div class="form-group">
    <label for="email_address">Semesters:</label>
    <select class="form-control" name="semesters" >
      <option value="1" <?php echo ($course_info['semesters'] == '1')?'selected':'' ?>>1</option>
      <option value="2" <?php echo ($course_info['semesters'] == '2')?'selected':'' ?>>2</option>
      <option value="3" <?php echo ($course_info['semesters'] == '3')?'selected':'' ?>>3</option>
      <option value="4" <?php echo ($course_info['semesters'] == '4')?'selected':'' ?>>4</option>
      <option value="5" <?php echo ($course_info['semesters'] == '5')?'selected':'' ?>>5</option>
      <option value="6" <?php echo ($course_info['semesters'] == '6')?'selected':'' ?>>6</option>
    </select>
    <!-- <input type="email" class="form-control" value="<?php  if(isset($course_info['school_email'])){echo $course_info['school_email']; }?>" name="school_email" id="school_email" required="" maxlength="50"> -->
  </div>
     <div class="form-group">
    <label for="contact">Duration:</label>
    <select class="form-control" name="duration" >
      <option value="1" <?php echo ($course_info['duration'] == '1')?'selected':'' ?>>1 year</option>
      <option value="2" <?php echo ($course_info['duration'] == '2')?'selected':'' ?>>2 year</option>
      <option value="3" <?php echo ($course_info['duration'] == '3')?'selected':'' ?>>3 year</option>
      <option value="4" <?php echo ($course_info['duration'] == '4')?'selected':'' ?>>4 year</option>
      <option value="5" <?php echo ($course_info['duration'] == '5')?'selected':'' ?>>5 year</option>
      <option value="6" <?php echo ($course_info['duration'] == '6')?'selected':'' ?>>6 year</option>
      <option value="7" <?php echo ($course_info['duration'] == '7')?'selected':'' ?>>7 year</option>
      
    </select>
    <!-- <input type="text" class="form-control" value="<?php  if(isset($course_info['address'])){echo $course_info['address']; }?>" name="address" id="address"  maxlength="50"> -->
  </div>
    
  <div class="form-group">
    <label for="country">Description:</label>
    <input type="text" name="desc" value="<?php  if(isset($course_info['desc'])){echo $course_info['desc']; }?>" id="desc" class="form-control"  maxlength="50">
  </div>
              
  <?php if(!empty($student_list)) { ?>
      <div class="form-group">
          <label for="gender">School:</label>
          <select id="schools" multiple="multiple" name="schools[]">
            <?php
            if(!empty($course_info['allocated_school'])){
                    $schoolarray = explode(',', $course_info['allocated_school']);
                  }else{
                    $schoolarray = array('');
                  }
            //$schoolarray = explode(',', $course_info['allocated_school']);
            foreach ($student_list as $key => $value) { ?>
              <option value="<?php echo $value['school_id']; ?>" <?php echo (in_array($value['school_id'],$schoolarray))?'selected':''; ?>>
                <?php echo $value['school_name']; ?></option> 
            <?php }
            ?>
              
          </select>
      </div>
      <?php } ?> 
  
              <input type="submit" class="button button-green  pull-right"  value="Update"/>
</form> 
   
  
     
   
  </div>
     
</div>
