<div class="container " > 
    

    <div class="row content">

     
           
        <a type="button" href="<?php echo site_url('course'); ?>"  class="button button-purple mt-12 pull-right">View Course List</a> 
     
 <h3>ADD Course Info</h3>
                  <?php 
        
        if(isset($_SESSION['message'])){
               echo "<p class='custom-alert'>".$_SESSION['message']."</p>";
         unset($_SESSION['message']);
        }
    
        
        ?>
     
          <hr/>
           
           
           
           
   <form method="post"  id="create_school_info_frm" action="<?php echo site_url('Course/create_course_info'); ?>" >
            <div class="form-group">
       
    <label for="school_name">Course Name:</label>
    
    <input type="text" name="course_name"  id="course_name" class="form-control" required="" maxlength="50">
 
   </div>
  <div class="form-group">
    <label for="email_address">Semesters:</label>
    <select class="form-control" name="semesters" >
      <option value="1" >1</option>
      <option value="2" >2</option>
      <option value="3" >3</option>
      <option value="4" >4</option>
      <option value="5" >5</option>
      <option value="6" >6</option>
    </select>
    <!-- <input type="email" class="form-control" value="<?php  if(isset($course_info['school_email'])){echo $course_info['school_email']; }?>" name="school_email" id="school_email" required="" maxlength="50"> -->
  </div>
     <div class="form-group">
    <label for="contact">Duration:</label>
    <select class="form-control" name="duration" >
      <option value="1" >1 year</option>
      <option value="2" >2 year</option>
      <option value="3" >3 year</option>
      <option value="4" >4 year</option>
      <option value="5" >5 year</option>
      <option value="6" >6 year</option>
      <option value="7" >7 year</option>
      
    </select>
    <!-- <input type="text" class="form-control" value="<?php  if(isset($course_info['address'])){echo $course_info['address']; }?>" name="address" id="address"  maxlength="50"> -->
  </div>
    
  <div class="form-group">
    <label for="country">Description:</label>
    <input type="text" name="desc"  id="desc" class="form-control"  maxlength="50">
  </div>
      <?php if(!empty($student_list)) { ?>
      <div class="form-group">
          <label for="gender">School:</label>
          <select id="schools" multiple="multiple" name="schools[]">
            <?php
            foreach ($student_list as $key => $value) { ?>
              <option value="<?php echo $value['school_id']; ?>">
                <?php echo $value['school_name']; ?></option> 
            <?php }
            ?>
              
          </select>
      </div>
      <?php } ?> 
                <div class="form-group mb-50">
            <input type="submit" class="button button-green  pull-right"  value="Submit"/>
                </div>
                
        </form> 
  
     
   
  </div>
     
</div>
