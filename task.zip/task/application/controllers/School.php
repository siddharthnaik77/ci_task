<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class School extends CI_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->model('School_model','school');
        $this->load->model('Course_model','course');
        
    }

    public function index() {

        $this->load->library('pagination');
        $config['per_page'] = 10;

        $page = $this->input->get('page', true);
        $search_data = $this->input->get('search_data', true);
        $total_row = $this->school->getSchoolsCount();
        
        $this->db->limit($config['per_page'], $page);
        $this->db->order_by("school_id", "desc");
        $result['student_list'] = $this->school->getSchools($config['per_page'],$page,$search_data);
        $config['base_url'] = "http://localhost/task/school?search_data=$search_data";
        $config['total_rows'] = $total_row;
        $config['use_page_numbers'] = TRUE;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';
        $config['full_tag_open'] = "<ul class='pagination'>";
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['prev_link'] = '&lt;Previous';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next &gt;</i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';


        $this->pagination->initialize($config);
        $result['pagination'] = $this->pagination->create_links();
        $data['content'] = $this->load->view('school_list', $result, true);
        
        $this->load->view('master', $data);
    }

    public function create_school_info() {
        

        if (isset($_POST['school_name'])) {
            $post_data = $_POST;
            if(!empty($_POST['courses'])){
                $courses=implode(',',$_POST['courses']);
            }else{
                $courses='';
            }
            
            $schoolData = array('school_name'=>$post_data['school_name'],'school_email'=>$post_data['email_address'],'address'=>$post_data['contact'],'country'=> $post_data['country'],'allocated_course'=> $courses);
             
            $result = $this->school->addSchool($schoolData);   
            if ($result) {
                $this->session->set_flashdata('message', 'Succefully Created Student Info.');
            } else {
                $this->session->set_flashdata('message', "An error occurred while inserting data.");
            }
            redirect('/');
        }
    }

    public function view_student_info($school_id) {
        if ($school_id != '') {
            $row['school_info'] = $this->school->getSchool($school_id);
        }
        $data['content'] = $this->load->view('view_school_info', $row, true);
        $this->load->view('master', $data);
    }

    public function update_student_info($school_id) {


        if (isset($_POST['school_id'])) {
            $update_data = $_POST;
            if(!empty($_POST['courses'])){
                $courses=implode(',',$_POST['courses']);
            }else{
                $courses='';
            }
           
            $school_id = $update_data['school_id'];
            
            $schoolData = array('school_name'=>$update_data['school_name'],'school_email'=>$update_data['school_email'],'address'=>$update_data['address'],'country'=> $update_data['country'],'allocated_course'=> $courses);
            $result = $this->school->updateSchool($schoolData,$school_id);

            if ($result) {

                $this->session->set_flashdata('message', 'Succefully Updated Student Info.');
            } else {
                $this->session->set_flashdata('message', 'An error occurred while inserting data');
            }

            //  redirect('student');
        }
        if ($school_id != '') {
           $row['school_info'] = $this->school->getSchool($school_id);
           $row['courses_list'] = $this->course->getCourses(NULL,NULL,NULL);
        }
        $data['content'] = $this->load->view('update_school_info', $row, true);
        $this->load->view('master', $data);
    }

    public function delete_student_info($school_id) {

        if ($school_id != '') {
            $result = $this->school->deleteSchool($school_id);
            if ($result) {
                $this->session->set_flashdata('message', 'Succefully Deleted Student Info.');
            } else {
                $this->session->set_flashdata('message', "An error occurred while inserting data.");
            }
            redirect('/');
        }
    }

    public function school_form(){
        $row['courses_list'] = $this->course->getCourses(NULL,NULL,NULL);
        $data['content'] = $this->load->view('school_add',$row, true);
        $this->load->view('master', $data);   
    }

}
