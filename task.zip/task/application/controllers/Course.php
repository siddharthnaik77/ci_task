<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Course extends CI_Controller
{
    function __construct() {
        parent::__construct();
        $this->load->model('Course_model','course');
        $this->load->model('School_model','school');
        
    }

    public function index() {

        $this->load->library('pagination');
        $config['per_page'] = 10;

        $page = $this->input->get('page', true);
        $search_data = $this->input->get('search_data', true);

        $total_row = $this->course->getCoursesCount();
        $result['courses_list'] = $this->course->getCourses($config['per_page'],$page,$search_data);

        $config['base_url'] = "http://localhost/task/course?search_data=$search_data";
        $config['total_rows'] = $total_row;
        $config['use_page_numbers'] = TRUE;
        $config['page_query_string'] = TRUE;
        $config['query_string_segment'] = 'page';
        $config['full_tag_open'] = "<ul class='pagination'>";
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['first_tag_open'] = '<li>';
        $config['first_tag_close'] = '</li>';
        $config['last_tag_open'] = '<li>';
        $config['last_tag_close'] = '</li>';
        $config['prev_link'] = '&lt;Previous';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_link'] = 'Next &gt;</i>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';


        $this->pagination->initialize($config);
        $result['pagination'] = $this->pagination->create_links();
        $data['content'] = $this->load->view('course_list', $result, true);
        
        $this->load->view('master', $data);
    }

    public function create_course_info() {


        if (isset($_POST['course_name'])) {
            $post_data = $_POST;
            if(!empty($_POST['course_name'])){
                $school=implode(',',$_POST['courses']);
            }else{
                $school='';
            }
            
            $courseData = array('course_name'=>$post_data['course_name'],'semesters'=>$post_data['semesters'],'duration'=>$post_data['duration'],'desc'=> $post_data['desc'],'allocated_school'=> $courses);
             
            $result = $this->course->addCourse($courseData);  
            if ($result) {
                $this->session->set_flashdata('message', 'Succefully Created Student Info.');
            } else {
                $this->session->set_flashdata('message', "An error occurred while inserting data.");
            }
            redirect('student');
        }
    }

    public function view_course_info($course_id) {
        if ($course_id != '') {
            $row['course_info'] = $this->course->getCourse($course_id);
        }
        $data['content'] = $this->load->view('view_course_info', $row, true);
        $this->load->view('master', $data);
    }

    public function update_course_info($course_id) {


        if (isset($_POST['course_id'])) {
            $update_data = $_POST;
            $course_id = $update_data['course_id'];
            unset($update_data['course_id']);
            if(!empty($_POST['schools'])){
                $schools=implode(',',$_POST['schools']);
            }else{
                $schools='';
            }
            
            $courseData = array('course_name'=>$update_data['course_name'],'semesters'=>$update_data['semesters'],'duration'=>$update_data['duration'],'desc'=> $update_data['desc'],'allocated_school'=> $schools);
            $result = $this->course->updateCourse($courseData,$course_id);

            if ($result) {

                $this->session->set_flashdata('message', 'Succefully Updated Student Info.');
            } else {
                $this->session->set_flashdata('message', 'An error occurred while inserting data');
            }

              redirect('courses');
        }
        if ($course_id != '') {
           $row['course_info'] = $this->course->getCourse($course_id);
           $row['student_list'] = $this->school->getSchools(NULL,NULL,NULL);
        }
        $data['content'] = $this->load->view('update_course_info', $row, true);
        $this->load->view('master', $data);
    }

    public function delete_course_info($course_id) {

        if ($course_id != '') {
            $result = $this->course->deleteCourse($course_id);
            if ($result) {
                $this->session->set_flashdata('message', 'Succefully Deleted Student Info.');
            } else {
                $this->session->set_flashdata('message', "An error occurred while inserting data.");
            }
            redirect('/courses');
        }
    }

    public function course_form(){
        $row['student_list'] = $this->school->getSchools(NULL,NULL,NULL);
        $data['content'] = $this->load->view('course_add',$row, true);
        $this->load->view('master', $data);   
    }

}
